t = (5, 'program', 1+3j)
print(t)
print("====SET====")
a = {1,2,2,3,3,3}
print(a)
b = list('HELLO'), tuple({5,6,7}), set([1,2,3])
print(b)
print("====DICTIONARY====")
d = {1:'value','key':2}
print(type(2))
print("d[1] = ", d[1]);
print("d['key'] = ", d['key']);
e = dict([[1,2],[3,4]]), dict([(3,26),(4,44)])
print (e)
# print("d[2] = ", d[2]); akan terjadi error krn bkn value
print("====CONVERSION====")
a = float(5), int(10.6), int(-10.6)
print(a)

