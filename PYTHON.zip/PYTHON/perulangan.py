print('FOR STATEMENT'.center(45,'='))
for letter in 'Python':
    print('current Letter: {}'.format(letter)) #urut berdasar abjad
fruits = ['banana', 'apple', 'manggo']
for fruit in fruits:
    print('current fruit: {}'.format(fruit)) #mengurutkan berdasar nama buah

print('WHILE STATEMENT'.center(45,'='))
count = 0
while (count < 5):
    print('The count is: {}'.format(count))
    count = count+1

print('PERULANGAN BERTINGKAT'.center(45,'='))
for i in range(0, 5):
    for j in range(0, 5 - i):
        print('*', end='')
    print()
