a = 5.5
print(a, "is of type", type(a))

a=3; print(float(a))
d = "Dicoding"
d[3]
animal = ['cat', 'rabbit', 'tiger', 'wolf']
del animal[1]
animal
for letter in 'Python':
    if letter.isupper():
        pass  
    else:
        print('Output: {}'.format(letter))
