s = "Hello World!"
print(s[4])
print(s[6:11])
# s[5]="d"  # error karena tdk bersifat immutable

s = "Hello world"
print(s)
s = "Try python"
print(s)
