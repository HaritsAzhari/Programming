print('MEMANGGIL FUNGSI'.center(45,'='))
def printme(str): #mendefinisikan fungsi
    print(str)
    return #mengembalikan nilai string

printme("Pemanggilan pertama")
printme("Pemanggilan kedua")

print('RETURN'.center(45,'='))
def sum (arg1, arg2):
    total = arg1 + arg2
    print('Inside the function: {}'.format(total))
    return total

total = sum(10, 20);
print('Outside the function: {}'.format(total))
print()
def kuadrat(x):
    return x*x
a = 10
k = kuadrat(a)
print('nilai kuadrat dari {} adalah {}'.format(a, k))

print('Pass by reference vs value'.center(45,'='))
#“passed by reference”. Artinya saat Anda mengubah
#sebuah variabel, maka data yang mereferensi padanya juga akan berubah,
def changeme(mylist):
    mylist.append([1,2,3,4])
    print('Nilai di dalam fungsi: {}'.format(mylist))

mylist = [10, 20, 30]
changeme(mylist)
print('Nilai diluar fungsi: {}'.format(mylist))

print('ARGUMEN FUNGSI'.center(45,'='))
def printme(str):
    print(str)
    return

printme("Hii") #Required argument, jika kosong maka error
printme(str = "My String") #keyword argument, memanggil argument dengan kata kunci

def defaultprint(name, age=35): #implementasi default arguments
    print('Name : ', name)
    print('Age : ', age)

defaultprint(age=5, name='Dicoding')
defaultprint(name='Data')
print()

def printinfo(fixedarg, *args): #Implementasi variable-length arguments
    "This prints a variable passed arguments"
    print('Output: fixedarg {}'.format(fixedarg))
    for a in args:
        print('argumen posisi {}'.format(a))
 
# Panggil printinfo 
printinfo(10)
printinfo(70, 60, 50)

print('FUNGSI ANONIM'.center(45,'='))

sum = lambda arg1, arg2: arg1 + arg2;
#memanggil fungsi lambda
print("Value Total : ",sum(10, 20))
print("Value Total : ",sum(20, 20))

print('CAKUPAN VARIABEL'.center(45,'='))

total = 0 #variabel global
def sum(arg1, arg2):
    global total #dibilang rumit saat melakukan debugging
    total = arg1+arg2
    print('Inside the function: {}'.format(total))
    return total

sum(10, 20)
print('Outside the function: {}'.format(total))






