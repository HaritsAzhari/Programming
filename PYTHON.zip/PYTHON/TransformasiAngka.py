x = 1
str(x).zfill(5)
print(str(x).zfill(5))
x
p = 'Hello world!'
p = p.upper()
q = 'Hello world!'
q = q.lower()
q
feeling = input('How are you?')
if feeling.lower() == 'great':
    print('I feel great too.')
else:
    print('I hope the rest of your day is good.')
print("========ISUPPER dan ISLOWER========")
r = 'Hello world'
r.islower() #apakah semua huruf kecil semua, kalo ada besarnya maka false
r.isupper() #apakah semua huruf Besar semua, kalo ada kecilnya maka false
print(r.islower()) #hasilnya false
print(r.isupper()) #false

'HELLO'.isupper()
print('HELLO'.isupper()) #hasilnya True
'abc12345'.islower()
print('abc12345'.islower())
print()
print('Hello'.upper())
print('Hello'.upper().lower())
print('Hello'.upper().lower().upper())
print('HELLO'.lower())
print('HELLO'.lower().islower())
print("========METODE isX========")
'hello'.isalpha() #mengecheck apakah kecampuran angka
print('hello'.isalpha()) #true
'hello123'.isalpha()
print('hello123'.isalpha())
'hello123'.isalnum() #mengecek apakah ada huruf aja atau angka aja atau keduanya
print('hello123'.isalnum())
'123d'.isdecimal() #mengecek apakah semua angka, kalo kecampuran huruf jadi false
print('123d'.isdecimal())
'  '.isspace() #mengecek apakah spacinya tanpa ada karakter. klo tidak maka True
print('  '.isspace())
'This Is Title Case'.istitle() #kelo judul harus kapital semua agar True
print('This Is Title Case'.istitle())
print("========METODE STARTENDWITH========")
'Hello world!'.startswith('Hello') #cek apakah starts kalimatnya sama dengan statement
print('Hello world!'.startswith('Hello')) #harus sama hurufnya disesuaikan sttmnt
print('Hello world!'.endswith('world!')) #bisa juga semua statemen dimasukkan akan menjadi TRUE
print("========METODE JOIN SPLIT========")
', '.join(['cats', 'rats', 'bats']) #menambahkan karaktaer (, )
print(', '.join(['cats', 'rats', 'bats']))
' '.join(['My', 'name', 'is', 'Simon']) #menambahkan karakter( )
print(' '.join(['My', 'name', 'is', 'Simon']))
'My name is Simon'.split() #memisahkan statement menjadi pecahan per kata
print('My name is Simon'.split())
print('MyABCnameABCisABCSimon'.split('ABC'))
print('My name is Simon'.split('m'))
print("========METODE rjust, Ijust, center========")
'Hello'.rjust(10) #menjadikan teks bergerak ke kanan(right)
print('Hello'.rjust(10))
print('Hello'.rjust(10,'*')) #menambahkan karakter '*' di sela spaci di kiri
'Hello'.ljust(10)
print('Hello'.ljust(10))
print('Hello'.ljust(10,'*')) #menambahkan karakter '*' di sela spaci di kanan
'Hello'.center(20)
print('Hello'.center(20))
print('Hello'.center(20,'=')) #menambahkan karakter '=' di antara kiri kanan
'Strip,rstrip,lstrip'.center(45)
print('Strip,rstrip,lstrip'.center(45,'='))
spam='      Hello World      '
spam.rstrip()
spam.strip() #menghilangkan karakter
spam.lstrip()
print(spam.rstrip()) #menghapus spasi kanan
print(spam.strip()) #menghapus spasi keduanya
print(spam.lstrip()) #menghapus spasi kiri
spam = 'SpamSpamBaconSpamEggsSpamSpam'
spam.strip('mapS') #sama dengan spam, boleh dibolak balik
print(spam.strip('mapS'))
'Replace()'.center(45)
print('Replace()'.center(45,'='))
string = "Ayo belajar Coding di Dicoding" #mengganti coding dengan pemrograman
print(string.replace("Coding", "Pemrograman"))
string = "Ayo belajar Coding di Dicoding karena Coding adalah bahasa masa depan"
print(string.replace("Coding", "Pemrograman", 1)) #hanya menganti coding di kalimat pertama dari kiri ke kanan




exit()
