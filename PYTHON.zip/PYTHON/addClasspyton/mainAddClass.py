import hello

#panggil
hello.world()

#cetak
print(hello.nama)

#review
diko = hello.Reviewer("Diko","Python")
diko.review()
