l = [1,2,3,3,4,4,4,4,5,6]
s = set(l) #untuk menyeleksi karakter jika berbeda maka diambil (1)
x = "Hello, World"
 
print(l)
print(len(l)) #panjang karakter
 
print(s)
print(len(s)) #menampilkan panjang karakter yang telah di set()
 
print(x)
print(len(x))

'PENGGABUNGAN REPLIKASI'.center(45)
print('PENGGABUNGAN REPLIKASI'.center(45,'='))

a = [1,2,3] + ['A','B','C'] #mengambungkan sebuah karakter
print(a)

b = ['X','Y,','Z'] * 3 #melipatgandakan karakter sebanyak 3 kali
print(b)

spam = [1,2,3]
spam = spam + ['A','B','C']
print(spam) #menggabungkan spam(123) dengan (ABC)

arr =[4]*10
len(arr)
print(arr) #jumlah 4 sebanyak 10kali
print(len(arr)) #panjang karakter angka 4 

'RANGE'.center(45)
print('RANGE'.center(45,'='))

for i in range(9): #dimulai dari nol dan terus menurun
    print(i) #parameter 1
print()
for j in range(3, 9): #dimulai dari angka 3 sampai 8 dengan kurang dri 9
    print(j)
print()
[_ for _ in range(1,9,2)]
print([_ for _ in range(1,9,2)])

'in dan not in'.center(45)
print('in dan not in'.center(45,'='))

'howdy' in ['hello','hi', 'howdy', 'heyas'] #menyeleksi statement apakah ada kata howdy
print('howdy' in ['hello','hi', 'howdy', 'heyas']) # jika ada maka TRUE

spam = ['hello','hi', 'howdy', 'heyas']
'cat' in spam #menyeleksi kata 'cat' apakah ada di variable spam jika tidak maka FALSE
print('cat' in spam)
'howdy' not in spam #not in menandakan bahwa howdy yg ada di statement dihilangkan jadi FALSE
print('howdy' not in spam)
'cat' not in spam #cat yang tidak ada di statement diadakan maka hasil mjd TRUE
print('cat' not in spam)

'MENGHILANGKAN NILAI (ASSIGMENT)'.center(45)
print('MENGHILANGKAN NILAI (ASSIGMENT)'.center(45,'='))

a,b ='alic', 'bob'
a,b = b,a #alic(a), dan bob(b). ditukar balik menjadi bob(a) dan alic(b)
print(a)
print(b)

'SORT'.center(45)
print('SORT'.center(45,'='))

x = [2,5,3.14,1,-7]
x.sort() #mengurutkan bilangan terkecil sampai terbesar
print(x)

y = ['ants', 'cats', 'dogs', 'badgers', 'elephants']
y.sort() #mengurutkan bilangan dari yang awal sampai terakhir
print(y)
y.sort(reverse=True)
print(y)#kebalikan sort. mengurutkan bilangan dari akhir ke awal
#Metode sort tidak dapat mengurutkan list yang memiliki angka dan - 
#string sekaligus di dalamnya.
m = ['Alice', 'ants', 'Bob', 'badgers', 'Carol', 'cats']
m.sort()
print(m) #diurutkan dari huruf besar dan awal ke huruf kecil abjad akhir
spam = ['a', 'z', 'A', 'Z']
spam.sort(key=str.lower)
print(spam) #mengurutkan abjad awal huruf kecil ke abjad akhir huruf besar/kapital

'STRING LITERALS'.center(45)
print('STRING LITERALS'.center(45,'='))

st = 'Say hi to Bob\'s mother.' #agar tidak ambigu fungsi (')
print(st)
sv = 'Hello there!\nHow are you?\nI\'m doing fine.' #menambahkan garis baru
print(sv)

'RAW STRINGS'.center(45)
print('RAW STRINGS'.center(45,'='))

sr = r'That is Carol\'s cat.' #membuka semua raw string yang ada
print(sr) #outputnya sama [That is Carol\'s cat.]
