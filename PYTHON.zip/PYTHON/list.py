a = [1,2.2, 'python']
print(a)
print(a[2])  # Hasilnya python
print("===============")
x = [5,10,15,20,25,30,35,40]
print(x[5])
print(x[-2]) # Akan mengambil elemen ke barisan belakang nomor 2 yaitu 35
print(x[3:5])
print(x[:5]) # Mengambil elemen awal sampai sebelum baris ke 5
print(x[-3:7]) # Mengambil elemen baris -3 sampai sebelum baris ke-7
print(x[-3:]) # mengambil elemen dari belakan nomor 3 sampai paling belakang
print(x[1:7:2])
print("================")
x = [1,2,3]
x[2] = 4
print(x)
x.append(5) # menambahkan angka 5
print(x)
print("================")
spam =['cat', 'bat', 'rat', 'elephant']
del spam[2] # Menghapus 'rat'
print(spam)

int(2+3)
