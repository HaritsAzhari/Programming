print('Menambahkan modul pada Python Path'.center(45,'='))


import sys
sys.path.append('/17006906_ISMAHMUDI HA/DICODING/PYTHON/Code_implementation/')
import codeimp
