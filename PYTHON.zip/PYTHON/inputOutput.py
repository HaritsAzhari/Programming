print("========VARIABLE STRING========")
a = 5
print('The value is', a)
print('hello {}'.format('kakak'))

name = "john"
age = 15
print("Hello, %s!" % name) #argumen %s untuk String %d untuk integer
print("%s is %d years old."%(name, age))

print("========INPUT========")
num = input('Enter a number : ')
print(num)
b = int(num)
print(b)
c = float(num)
print(c)
a = eval('2+3')
print(a)

print("========COMMAND LINE========")
$ python inputOutput.py arg1 arg2 arg3
import sys
print('Number of arguments:', len(sys.argv),'arguments.')
print('Argument List:', str(sys.argv))
print(sys.argv[1])
