print('BREAK'.center(45,'='))
for letter in 'Python':
    if letter == 'h':
        break #for terhenti sampai t.
    print('current letter: {}'.format(letter))

var = 10
while var > 0:
    print('current variable value: {}'.format(var))
    var = var - 1
    if var == 5:
        break

print('CONTINUE'.center(45,'='))

for letter in 'Python':
    if letter == 'h':
        continue #melanjutkan abjad dengan melewati abjad 'h'
    print('Current letter: {}'.format(letter))
print()

for a in[0,1,-1,2,-2,3,-3]:
    if a <=0:
        continue #menyeleksi elemen positif
    print('Elemen Positif: {}'.format(a))

print('ELSE SETELAH FOR'.center(45,'='))
#Fungsinya diutamakan pada perulangan yang bersifat
#pencarian - untuk memberikan jalan keluar program saat pencarian tidak ditemukan.

#for item in container:
#    if search_something(item):
       # Found it!
#        process(item)
#        break
#else:
    # Didn't find anything..
#    not_found_in_container()

for n in range(2, 10):
    for x in range(2, n):
        if n % x == 0:
            print(n, 'equals', x, '*', n/x)
            break
else: #jika kondisi atas terpenuhi selanjutnya menesekusi bawah
    print(n, 'is a prime number')

print('ELSE SETELAH WHILE'.center(45,'='))
#akan selalu dieksekusi saat kondisi pada while menjadi salah.
n = 5
while n > 0:
    n = n - 1
    if n == 2:
        break
    print(n)
else: #jika kondisi atas terpenuhi selanjutnya menesekusi bawah
        print("Loop is finished")

print('PASS'.center(45,'='))
#Kontrol ini banyak digunakan saat Anda belum melakukan
#implementasi (dan mengisi pernyataan dengan seharusnya)
#serta membiarkan program tetap berjalan saat misalnya Anda mengalami kegagalan atau exception.
for letter in 'Python':
    if letter == 'h':
        pass
        print ("This is pass block") #abjad h akan diganti seperti statement itu
    print('Current letter: {}'.format(letter))
print()

for letter in 'PytHon':
    if letter.isupper(): #menghilangkan abjad kapital
        pass  # will process later
    else:
        print('Lower letter: {}'.format(letter))

print('LIST COMPREHENSION'.center(45,'='))
numbers = [1,2,3,4]
squares = []
for n in numbers:
    squares.append(n**2) #mengalikan variable numbers
    print(squares) #membuat segitiga bilangan

print("ATAU")

numbers = [1, 2, 3, 4]
squares = [n**2 for n in numbers]
print(squares) #hanya 1 baris dari hasil kali var numbers dengan squares n**2

list_a = [1, 2, 3, 4]
list_b = [2, 3, 4, 5]
common_num = [a for a in list_a for b in list_b if a == b]
print(common_num) # Output: [2, 3, 4]

list_a = ["Hello", "World", "In", "Python"]
small_list_a = [_.lower() for _ in list_a]
print(small_list_a)#mengecilkan semua huruf

list_a = range(1, 10, 2) # [1,3,5,7,9]
x = [[a**2, a**3] for a in list_a] #[1^2, 1^3], [3^2, 3^3], ...[9^2, 9^3]
print(x)
