print('Menambahkan class'.center(45, '='))

def world():
    print("Hello, World!")

nama = "Dicoding"

class Reviewer:
    def__init__(self, nama, kelas):
        self.nama = nama
        self.kelas = kelas

    def review(self):
        print("Reviewer " + self.nama + " bertanggung jawab di kelas " + self.kelas)
        
