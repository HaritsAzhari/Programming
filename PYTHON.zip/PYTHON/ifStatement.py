'IF STATEMENT'.center(45)
print('IF STATEMENT'.center(45,'='))

var1 = 100
if var1:
    print("1 - GOT TRUE EXPRESSIONS")
    print (var1)

var2 = 0
if var2:
    print("2 - GOT TRUE EXPRESSIONS")
    print(var2)

#'ELSE STATEMENT'.center(45)
print('ELSE STATEMENT'.center(45,'='))
amount = int(input("Enter amount: "))
if amount < 1000:
    discount = amount*0.05
    print ("Discount", discount)
else: #jika statement tak terpenuhi maka akan masuk ke kondisi else
    discount = amount*0.1
    print ("Discount", discount)

print("Net payable: ", amount-discount)
print()

a = 8
if a % 2 == 0:
    print('bilangan {} adalah genap'.format(a))
else:
    print('bilangan {} adalah ganjil'.format(a))

print('ELIF(ELSE IF) STATEMENT'.center(45,'='))

amount = int(input("Enter amount: "))
if amount<1000:
   discount = amount*0.05
   print ("Discount",discount)
elif amount<5000: #kependekan dari else if
   discount = amount*0.10
   print ("Discount",discount)
else:
   discount = amount*0.15
   print ("Discount",discount)
print ("Net payable:",amount-discount)


#Ternary operation Operator menentukan sesuatu berdasarkan kondisi True atau False.
#ShortHand Ternary mungkin membantu Anda untuk memeriksa kode/hasil dari sebuah fungsi dan memastikan outputnya
#tidak menyebabkan error (atau minimal memberikan informasi relevan saat error):


