#definisi
def world():
    print("Hello, World!")

#panggil sini
world()
