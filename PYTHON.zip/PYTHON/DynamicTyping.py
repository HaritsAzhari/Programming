thing = "Hello"
type(thing)

thing = 28.1
type(thing)
