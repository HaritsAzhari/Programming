print('OOP PADA PYTHON'.center(45,'='))

class Kalkulator: #OOP class
    """contoh kelas kalkulator sederhana"""
    i = 12345
 
    def f(self):
        return 'hello world'

Kalkulator.i = 1024
print(Kalkulator.i)
Kalkulator.f = 'hello python'
print(Kalkulator.f)

print()

print('OBJEK'.center(45,'='))

Kal = Kalkulator() #Object instat class
num = 12345

def abj(self):
    return 'hello world'

Kal.abj = 'Hello bro'
print(Kal.abj)

print('CLASS KONSTRUKTOR'.center(45,'='))

class Calculator:

    def __init__(self, i = 12345): # class konstruktor
        self.i = i #i adalah variabel konstruktor

    def f(self):
        return 'hello world!'

c = Calculator (i = 2048) #melakukan instantion dan mengisi attribut jadi 2048
print(c.i) #mencetak atribut i dari obj c dengan keluaran 2048

print('METHOD'.center(45,'='))

class Kalkulator:

    def a(self):
        return'hello world'

    @classmethod
    def tambah_angka(cls, angka1, angka2):
        return '{} + {} = {}'.format(angka1, angka2, angka1 + angka2)

Kalkulator.tambah_angka(1, 2)
print(Kalkulator.tambah_angka(1, 2))

k = Kalkulator()
k.tambah_angka(1, 2)
print(k.tambah_angka(1, 2))

class Kalkulator:

    def s(self):
        return'hello world'

    @staticmethod
    def kali_angka(angka1, angka2): #tidak ada cls yaa
        return '{} x {} = {}'.format(angka1, angka2, angka1 * angka2)

a = Kalkulator.kali_angka(2, 3)
print(a)

print('PEWARISAN (INHERITANCE)'.center(45,'='))

class Kalkulator: #kelas A
    """contoh kelas kalkulator sederhana. anggap kelas ini tidak boleh diubah!"""
 
    def __init__(self, nilai=0):
        self.nilai = nilai
 
    def tambah_angka(self, angka1, angka2):
        self.nilai = angka1 + angka2
        if self.nilai > 9:  # kalkulator sederhana hanya memroses sampai 9
            print('kalkulator sederhana melebihi batas angka: {}'.format(self.nilai))
        return self.nilai

class KalkulatorKali(Kalkulator): #kelas B
    """contoh mewarisi Kalkulator sederhana"""

    def kali_angka(self, angka1, angka2):
        self.nilai = angka1 * angka2
        return self.nilai

kk = KalkulatorKali()

a = kk.kali_angka(2, 9)
print(a)

b = kk.tambah_angka(5, 6)
print(b)

print('OVERRIDE METHOD'.center(45,'='))

class KalkulatorKali2(Kalkulator): #Override method (menimpa method kalkulator)
    """contoh mewarisi kelas kalkulator sederhana"""
 
    def kali_angkaa(self, angka1, angka2):
        self.nilai = angka1 * angka2
        return self.nilai
 
    def tambah_angkaa(self, angka1, angka2):
        self.nilai = angka1 + angka2
        return self.nilai

kk2 = KalkulatorKali2()

bb= kk2.tambah_angkaa(5, 6)
print(bb)


print('SUPERCLASS'.center(45,'='))

class KalkulatorTambah2(Kalkulator):
    """contoh mewarisi kelas kalkulator sederhana"""
 
    def tambah_angkaaa(self, angka1, angka2):
        if angka1 + angka2 <= 9:  # fitur ini sudah oke di kelas dasar, gunakan yang ada saja
            super().tambah_angkaaa(angka1, angka2)  # panggil fungsi dari Kalkulator lalu isi nilai
        else:  # ini adalah fitur baru yang ingin diperbaiki dari keterbatasan kelas dasar
            self.nilai = angka1 + angka2
        return self.nilai

kt = KalkulatorTambah2()

c = kt.tambah_angkaaa(5, 6)
print(c)
