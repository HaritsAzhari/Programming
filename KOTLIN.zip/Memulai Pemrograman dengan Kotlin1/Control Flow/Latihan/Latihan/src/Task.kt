/**
 * Untuk menyelesaikan tugas latihan, Anda tidak diperbolehkan mengubah struktur kode yang sudah ada. Kecuali:
 *    - Untuk melakukan improvisasi kode
 *    - Mengikuti perintah yang ada
 *
 * Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan.
 *
 */

fun main() {
    val hasilAngka = 1.rangeTo(100)

    for (angka in hasilAngka) {
        // TODO 1

        if ( angka % 2 == 0 ) continue

        // TODO 2
        if ( angka > 15) break

        // TODO 3
        val result = angka * (angka + 10)
        println("range result is $result")
    }
}