// main function
fun main() {
    println(10.plusThree())
}

fun Int.plusThree(): Int {
    return this + 3
}