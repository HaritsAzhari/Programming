/**
 * Untuk menyelesaikan tugas latihan, Anda tidak diperbolehkan mengubah struktur kode yang sudah ada. Kecuali:
 *    - Untuk melakukan improvisasi kode
 *    - Mengikuti perintah yang ada
 *
 * Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan.
 *
 */

fun main() {
    val first = "Kotlin".getFirstAndLast()
    val last = "Dicoding".getFirstAndLast()

    val karakterUtama = first["pertama"]
    val karakterTerakhir = first["terakhir"]

    val codingKarakterUtama = last["pertama"]
    val codingKarakterTerakhir = last["terakhir"]

    println("First char Kotlin is $karakterUtama and $karakterTerakhir for second letter")
    println("First char Dicoding is $codingKarakterUtama and $codingKarakterTerakhir for second letter")

}

// TODO\
fun String.getFirstAndLast(): Map<String, Char>{
    return mapOf(
            "pertama" to this.first(),
            "terakhir" to this.last()
    )
}