/**
 * Untuk menyelesaikan tugas latihan, Anda tidak diperbolehkan mengubah struktur kode yang sudah ada. Kecuali:
 *    - Untuk melakukan improvisasi kode
 *    - Mengikuti perintah yang ada
 *
 * Cukup tambahkan kode berdasarkan perintah yang sudah ditentukan.
 *
 */

fun main() {

    // TODO 1
    val vehicle  = mapOf<String, String>(
            "tipe" to "Motorcycle",
            "speedMax" to "230Km/s",
            "tankMax" to "10Ltr"

    )


    // TODO 2
    val type = vehicle.getValue("tipe")
    val maxSpeed = vehicle.getValue("speedMax")
    val maxTank = vehicle.getValue("tankMax")

    // TODO 3
    println("Vehicle")
    println("Type: $type")
    println("Maximal Speed: $maxSpeed")
    println("Maximal Tank: $maxTank")

}