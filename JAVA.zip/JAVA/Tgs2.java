import java.util.Scanner;
public class Tgs2
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int wal,kir,n1,n2,n3;
		String lagi;
		do
			{
			System.out.print("masukkan awal bilangan : ");
			wal =input.nextInt();
			System.out.print("masukkan akhir bilangan : ");
			kir =input.nextInt();
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("		RESULT		     ");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.print("Bilangan Genap : ");
			for(n1=wal;n1<=kir;n1++)
				{
				if(n1%2==0){
					System.out.print(n1+" ");
					   }
				}
			System.out.println("");
			System.out.print("Bilangan Ganjil : ");
			for(n2=wal;n2<=kir;n2++)
				{
				if(n2%2==1){
					System.out.print(n2+" ");
					   }
				}
			System.out.println("");
			System.out.print("Bilangan Prima : ");
			for(n3=wal;n3<=kir;n3++){
				int pembagi,X=0;
				for(pembagi=2;pembagi<=n3;pembagi++)
					{
					if(n3%pembagi==0){
					 if(n3 != pembagi){
						X=1;
							}
					if(X !=1 && n3 ==pembagi) {
						System.out.print(n3+" ");
							 }
						}
					}
				}
			System.out.println("");
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
			System.out.print("Apakah ingin mengulanginya lagi [Y/N] : ");
			lagi=input.next();
				}
			while("Y".equals(lagi));
		}
}