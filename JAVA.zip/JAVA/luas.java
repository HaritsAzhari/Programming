public class luas extends persegi {

	public int hitungluas(int sisi) {
		persegi p = new persegi();
		p.setSisi(sisi);

		int luas;
		luas = p.getSisi() * p.getSisi();
		return luas;
	}
}