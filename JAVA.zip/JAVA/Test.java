public class Test
{
	public static void main(String [] x)
	{ 
		System.out.println("Hai word");
	}
}