public class test311	
	{
	public void main(String args[]) {	
	System.out.println("What's wroung with this program?");		}
}