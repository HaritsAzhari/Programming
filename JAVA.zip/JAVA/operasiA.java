public class operasiA
{
	public static void main(String[] args)
	{
System.out.println("Operasi aritmatika "+"pada tipe floating-point");
double fa = 2 + 1;
double fb = fa - 1;
double fc = fa * fb;
double fd = fc / 3;
double fe = -fa;
System.out.println("nilai fa: " + fa);
System.out.println("nilai fb: " + fb);
System.out.println("nilai fc: " + fc);
System.out.println("nilai fd: " + fd);
System.out.println("nilai fe: " + fe);
}
}