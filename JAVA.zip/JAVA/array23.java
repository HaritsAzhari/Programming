public class array23
{
	public static void main(String[] args)
	{
	int[][][]data = new int[0][0][0];
	  for(int i=0;i<3;i++){
	    for(int j=0;j<3;j++){
	      for(int k=0;k<3;k++){
		System.out.println(+i+"|"+j+"|"+k);
				}
			}	
		}
	}
}