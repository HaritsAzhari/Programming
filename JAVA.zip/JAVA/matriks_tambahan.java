public class matriks_tambahan {
	public static void main(String[] args) {
		int a[][]={{3,2},{4,5}};
		int b[][]={{5,4},{6,8}};
		int penjumlahan [][]=new int [2][2];
		System.out.println ("matriks A");
		for (int i=0;i<2 ;i++ ) {
			for (int j=0;j<2 ;j++ ) {
				System.out.println(a[i][j]+" ");
				System.out.println(" ")
				System.out.println("Matriks B")
				for (int i=0;i<2;i++ ) {
					for (int j=0;j<2 ;j++ ) {
						System.out.println(b[i][j]+" ");
						System.out.println(" ")
						System.out.println("Hasil penjumlahan");
						for (int i=0; 1<2; j++ ) {
							for (int j=0; j<2; j++ ) {
								penjumlahan [i][j]=a[i][j]+b[i][j];
								System.out.print(penjumlahan[i][j]+" ");
								System.out.println(" ");
							}
							
						}

						
					}
					
				}
				
			}
			
		}
	}
}