public class latihanseg3
{
public static void main(String[] args) {
	int row;
	row=5;

	for (int i=1;i<=row ;i++) {
		for (int j=1;j<=row ;j++ ) {
			if (j<=i) 
				System.out.print("1");
			}
			for (int k=0;k<=row ;k++ ) {
				if(i<k)
					System.out.print("0");
				
			}
			System.out.println();
		}
	}
}