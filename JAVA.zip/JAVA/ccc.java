public class ccc {
public static void main (String []args) {
int a=3;
switch (a) {
	case 1:
	System.out.println("nilai a=1");
break;
	case 2:
	System.out.println("nilai a=2");
break;
	case 3:
	System.out.println("nilai a=3");
break;
	default:
	System.out.println("nilai a=4");
break;
}
}
}