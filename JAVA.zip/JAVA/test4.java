public class test4 
{	
	public static void main (String [] args)
	{
	System.out.println("what's wrong with this program?");
	}
}	
class TestAnother 
{	
	public void main(String [] args)
	{
	}
}