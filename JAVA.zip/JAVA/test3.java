public class test3 {	public static void main (String [] args)
{
	System.out.println("what's wrong your program");	}
}