public class tgs1
{
	public static void main(String [] o)
	{
		int x,y,z;
		for(x=1;x<5;x++)
			for(y=3;y<13;y+=3)
		{
			z=x*y;
			System.out.println(x+" x "+y +"=" +z);
		}
	}
}
		