public class Tugas2_Dowhiles3
{
public static void main(String[] o) {
	int x,y,z;
	x=1;
	do {
			y=0;
			do {
					System.out.print("1");
					y++;
					}while (y<x);
					if (x<5) {
					z = 5;
					do {
					System.out.print("0");
					z--;
				}while (z>x);
			}
				System.out.println();
				x++;
		}while (x<6);
	}
}