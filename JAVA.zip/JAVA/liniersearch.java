public class liniersearch {
	public static void main(String[] args) {
		int angka[] = new int [5];
		angka[0] = 5;
		angka[1] = 2;
		angka[2] = 7;
		angka[3] = 9;
		angka[4] = 4;
                boolean ketemu=false;
                int pos = 0;
                int cari;
                scanner baca = new Scanner(System.in);
                System.out.print("Masukkan bilangan yang ingin dicari posisinya : ");
                  cari=baca.nextInt();

                  while((!ketemu) &&(pos<5))
                  {
                  if(cari == angka(pos)) {
                  System.out.println("data "+cari"ditemukan di posisi : "(pos+1));
                  ketemu = true;
            }
           if(! ketemu && pos==4) {
           System.out.println("data"+cari"tidak ditemukan!!");
            ketemu=false;
         }     
        pos++
    }
}