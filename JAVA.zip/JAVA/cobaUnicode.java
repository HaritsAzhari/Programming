public class cobaUnicode
{
	public static void main(String args[])
	{
	char a='\u0063';
	char b='\u0042';
	char c='\u0055';
	String kata="\u0061\u0062\u0063";
	System.out.println("a:" +a);
	System.out.println("a:" +b);
	System.out.println("a:" +c);
	System.out.println("kata:" +kata);
	}
} 