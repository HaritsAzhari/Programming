public class Tugas_segitigablk
{
public static void main(String[] o) {
	int row;

	for (int i=1;i<=5 ;i++) {
		for (int j=1;j<=5 ;j++ ) {
			if (j<=i) 
				System.out.print("1");
			}
			for (int k=1;k<=5 ;k++ ) {
				if (i<=k)
					System.out.print("0");
			}
			System.out.println();
		}
	}
}