import java.util.Scanner;
public class Utama {
    
    public static void main(String[] args) {
        // TODO code application logic here
        // membuat objek dari class User
        
        String mId, mNama, mSekolah; 
        int mJk, mReg, mData;
        float mPre, mPos;
                
        Narsum mNarsum = new Narsum("Budianto","19800223 1999031 003", 1); 
        
        
        // deklarasi array
        Peserta[] mPeserta = new Peserta[2];
        //mData = mPeserta.length;
        mData = 2;
        
        
        //inisialisasi array
        for( int a = 0; a < mData; a++){
            mPeserta[a] = new Peserta();
        }
        
        Scanner baca = new Scanner(System.in);    
        
        // isi array
        //for (int a = 0; a < mPeserta.length; a++) {
        for (int a = 0; a < mData; a++) {
            System.out.print("ID Peserta ke-"+ (a+1) +": ");
            mId    = baca.next();
            
            System.out.print("Nama "+ (a+1) +": ");
            mNama  = baca.next();
            
            System.out.print("Sekolah "+ (a+1) +": ");
            mSekolah  = baca.next();
            
            System.out.print("JK (1 = PRIA; 0 = WANITA)"+ (a+1) +": ");
            mJk  = baca.nextInt();
            
            System.out.print("Registrasi (0 = blm hadir; 1 = hadir)"+ (a+1) +": ");
            mReg  = baca.nextInt();
            
            System.out.print("Nilai Pretest)"+ (a+1) +": ");
            mPre  = baca.nextFloat();
            
            System.out.print("Nilai Postest)"+ (a+1) +": ");
            mPos  = baca.nextFloat();
            
            mPeserta[a].setId(mId);
            mPeserta[a].setNama(mNama);
            mPeserta[a].setSekolah(mSekolah);
            mPeserta[a].setJk(mJk);
            mPeserta[a].setRegistrasi(mReg);
            mPeserta[a].setPretest(mPre);
            mPeserta[a].setPosttest(mPos);
        }

        System.out.println("================================================================================================================================");
        System.out.println("Nama Narsum\t"+ mNarsum.getNama());
        System.out.println("N I P\t\t"+ mNarsum.getNip());
        System.out.println("Gender\t\t"+ mNarsum.getJk());
        // cetak isi array
        System.out.println("================================================================================================================================");
        System.out.print("ID");
            System.out.print("\t");
            System.out.format("%-20s","Nama Peserta");
            System.out.print("\t");
            System.out.format("%-20s","Instansi");
            System.out.print("\t");
            System.out.format("%-6s","Gender");
            System.out.print("\t");
            System.out.format("%-10s","Registrasi");
            System.out.print("\t\t");
            System.out.print("Pretest");
            System.out.print("\t");
            System.out.print("Postest");
            System.out.print("\t");
            System.out.print("NA");
            System.out.print("\t");
            System.out.print("Grade");
            System.out.print("\t");
            System.out.println("Ket");
        System.out.println("================================================================================================================================");
        
        for (int a = 0; a < mData; a++) {
            System.out.print(mPeserta[a].getId());
            System.out.print("\t");
            System.out.format("%-20s",mPeserta[a].getNama());
            System.out.print("\t");
            System.out.format("%-20s",mPeserta[a].getSekolah());
            System.out.print("\t");
            System.out.format("%-6s",mPeserta[a].getJk());
            System.out.print("\t");
            System.out.format("%-10s",mPeserta[a].getRegistrasi());
            System.out.print("\t\t");
            System.out.print(mPeserta[a].getPretest());
            System.out.print("\t");
            System.out.print(mPeserta[a].getPosttest());
            System.out.print("\t");
            System.out.print(mPeserta[a].na());
            System.out.print("\t");
            System.out.print(mPeserta[a].range());
            System.out.print("\t");
            System.out.println(mPeserta[a].ket());
        }
        System.out.println("================================================================================================================================");
    }
}
