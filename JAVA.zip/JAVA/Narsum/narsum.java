package Narsum;
public class Narsum extends Pengguna{
    private String nip;

    public Narsum(){
        this.nip = "";
    }
    
    public Narsum(String nama, String nip, int jk){
        super();
        setNama(nama);
        setJk(jk);
        setNip(nip); 
    }
    public String getNip() {
        return nip;
    }

    public void setNip(String nip) {
        this.nip = nip;
    }
    
}