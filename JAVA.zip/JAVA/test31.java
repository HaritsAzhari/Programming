public class test31	
	{
	public void main(String args[]) {	
	System.out.println("What's wroung with this program?");		}
}