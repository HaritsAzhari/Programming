public class Tugas_Dowhiles3
{
public static void main(String[] args) 
	{
		int a=1,b;
		do 
		{
			b=1;
			do
			{
				System.out.print("1");
				b++;
			}
			while (b<=a);
			System.out.println(" ");
			a++;
		} while (a<=5);
	}
}