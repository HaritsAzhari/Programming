public class hitungB {
	int sisi,rumus;
	void jumlah(int sisi)
	{
		this.sisi = sisi;
		rumus = sisi*sisi*sisi;

		System.out.println("Volume Kubus = "+ rumus + " "+" cm^3");
	}
}