public class test3(1)	{
	public void main(String [] args); {	
	System.out.println("What's wroung with this program?");		}
	}