class aritmatika
{
public static void main(String []args)
{
	System.out.println("Operasi aritmatika"+"pada tipe integer");
	int a = 2 + 1;
	int b = a - 1;
	int c = a * b;
	int d = c / 3;
	int e = -a;
	System.out.println("Nilai a: "+a);
	System.out.println("Nilai b: "+b);
	System.out.println("Nilai c: "+c);
	System.out.println("Nilai d: "+d);
	System.out.println("Nilai e: "+e);
	System.out.println();
}
}