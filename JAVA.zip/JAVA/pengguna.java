public class pengguna {
    private String nama;
    private int jk;
    private int registrasi;

    public Pengguna(){
        this.nama = "";
        this.jk = 0;
        this.registrasi = 0;
    }
    
    public Pengguna(String nama, int jk){
        this.nama = nama;
        this.jk = jk;
    }
            
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getJk() {
        if (this.jk == 1)
        {
        return "PRIA";
        } else{
            return "WANITA";
        }
            
    }

    public void setJk(int jk) {
        this.jk = jk;
    }

    public String getRegistrasi() {
        if (this.registrasi == 0)
        {
        return "BLM HADIR";
        } else{
            return "HADIR";
        }
    }

    public void setRegistrasi(int registrasi) {
        this.registrasi = registrasi;
    }
    
}