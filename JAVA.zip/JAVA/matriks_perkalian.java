import java.util.Scanner;

public class matriks_perkalian {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);         
        int [][]matrixA=new int[2][2];
        int [][]matrixB=new int[2][2];
        int [][]hasil=new int[2][2];
        System.out.println("Matrix A");
        for(int a=0;a<2;a++){
            for(int b=0;b<2;b++){
                System.out.print( a + ":" + b + " = ");
                matrixA[a][b]=input.nextInt();
            }
        }
        System.out.println("Matrix B");
        for(int a=0;a<2;a++){
            for(int b=0;b<2;b++){
                System.out.print(a + ":" + b + " = ");
                matrixB[a][b]=input.nextInt();
            }
        }
        System.out.println("Matrix A");
        for(int a=0;a<2;a++){
            for(int b=0;b<2;b++){
                System.out.print(" "+matrixA[a][b]);
            }
            System.out.println(" ");
        }
        System.out.println("Matrix B");
        for(int a=0;a<2;a++){
            for(int b=0;b<2;b++){
                System.out.print(" "+matrixB[a][b]);
            }
            System.out.println(" ");
        }
        System.out.println("Hasil dari A X B ");
        for(int a=0;a<2;a++){
            for(int b=0;b<2;b++){
                for(int c=0;c<2;c++){
                    hasil[a][b]+=matrixA[a][c]*matrixB[c][b];
                }                
            }            
        }
        for(int a=0;a<2;a++){
            for(int b=0;b<2;b++){
                System.out.print(hasil[a][b]+" ");
            }
            System.out.println(" ");
         }
    }
}