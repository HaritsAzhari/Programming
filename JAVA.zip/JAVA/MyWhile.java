public class MyWhile
{
	public static void main(String [] o)
	{
		int hitung=0;
		while(hitung<10)
		{
		System.out.println("hallo dunia -"+hitung);
		hitung++;
		}
	}
}