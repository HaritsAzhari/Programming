public class Tugas2_whiles3
{
public static void main(String[] o) {
	int x,y,z;
	x=1;

	while (x<6) {
	y=0;
	while (y<x) {
					System.out.print("1");
					y++;
					}
					if (x<5) {
					z = 5;
					while (z>x) {
					System.out.print("0");
					z--;
					}
				}
				System.out.println();
				x++;
		}
	}
}