public class peserta extends Pengguna{
    private String id;
    private String sekolah;
    private float pretest;
    private float posttest;

    public Peserta(){
        this.id = "";
        this.sekolah = "";
        this.pretest = 0;
        this.posttest = 0;
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSekolah() {
        return sekolah;
    }

    public void setSekolah(String sekolah) {
        this.sekolah = sekolah;
    }

    public float getPretest() {
        return pretest;
    }

    public void setPretest(float pretest) {
        this.pretest = pretest;
    }

    public float getPosttest() {
        return posttest;
    }

    public void setPosttest(float posttest) {
        this.posttest = posttest;
    }
    
    public float na() {
        float hitung;
        
        hitung = (float) ((0.4 * pretest) + (0.6 * posttest));
        return hitung;
    }
  
    
    public String range() {
        String hasil = "-";
        float na = this.na();
        
        if (na() > 80) 
        {
            hasil = "A";
        }
        else
        {
            if (na() > 70) 
            {
                hasil = "B";
            }
            else
            {
                if (na() > 60) 
                {
                    hasil = "C";
                }
                else
                {
                    if (na() > 40) 
                    {
                        hasil = "D";
                    }
                    else
                    {
                        hasil = "E";
                    }
                }
            }
        }
        return hasil;
    }
    
    public String ket() {
        String hasil = "";
        String ket = "";
        hasil = this.range();
        switch(hasil){
        case "A":
            ket = "LULUS";
            break;
        case "B":
            ket = "LULUS";
            break;
        case "C":
            ket = "LULUS";
            break;
        case "D":
            ket = "ULANG";
            break;
        default:
            ket = "ULANG";
            break;
        }
        return ket;
    }
    
}