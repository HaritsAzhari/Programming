import java.util.Scanner;
class hitungA extends hitungB
{
	public static void main(String[] args) {
		String exit;
		do {
			hitungA data = new hitungA();
			int sisi;

			Scanner in = new Scanner(System.in);
			System.out.print("Masukkan Jumlah Panjang : ");
			sisi = in.nextInt();

			data.jumlah(sisi);
			System.out.print("Apakah anda ingin memasukkan data lagi?: ");
			exit = in.next();
		}
		while("y".equals(exit));
	}
}