public class MyDoWhile
{
	public static void main(String [] y)
	{
		int penghitung=0;
		do
		{
			System.out.println("Do while -"+penghitung);
			penghitung++;
		} while(penghitung <5);
	}
}