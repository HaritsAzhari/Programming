public class pertama {
	public static void main(String[] args) {
		mobil Hondi = new mobil();
		Hondi.setRoda(4);
		Hondi.setWarna("Hitam");
		Hondi.setTempat(6);

		System.out.println("Mobil Hondi : ");
		System.out.println("Roda  	= " +Hondi.getRoda());
		System.out.println("Warna 	= " +Hondi.getWarna());
		System.out.println("Tempat Duduk = " +Hondi.getTempat());

		System.out.println("");

	motor Yamahmud = new motor();
	Yamahmud.setRoda(2);
	Yamahmud.setWarna("Merah");

	System.out.println("Motor Yamahmud : ");
	System.out.println("Roda  	= " +Yamahmud.getRoda());
	System.out.println("Warna  	= " +Yamahmud.getWarna());
	}
}