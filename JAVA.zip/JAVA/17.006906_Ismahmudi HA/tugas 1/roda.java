import java.util.Scanner;
class roda extends kendaraan
{
	public static void main(String[] args) {
		String exit;
		do {
			int roda;
			roda data = new roda();
			Scanner in = new Scanner(System.in);
			System.out.print("Masukkan Jumlah Roda : ");
			roda = in.nextInt();
			data.jumlah(roda);
			System.out.print("Apakah anda ingin memasukkan data lagi?: ");
			exit = in.next();
		}
		while("y".equals(exit));
	}
}