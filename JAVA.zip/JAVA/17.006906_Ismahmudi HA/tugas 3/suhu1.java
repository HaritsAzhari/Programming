import java.util.Scanner;
public class suhu1 extends suhu {
	public static void main(String[] args) {
		suhu c = new suhu();
		Scanner in = new Scanner(System.in);

		System.out.print("Masukkan besar suhu dalam Celcius : ");
		double suhu = in.nextDouble();
		c.setCelcius(suhu);

		System.out.println("suhu dalam Reamur      :   "+ c.getReamur(c.getCelcius()));
		System.out.println("Suhu dalam Fahrentheit :   "+ c.getFahrentheit(c.getCelcius()));
		System.out.println("Suhu dalam Kelvin      :   "+ c.getKelvin(c.getCelcius()));

	}
}