public class suhu {
	private double celcius;

	public void setCelcius(double celcius) {
		this.celcius = celcius;
	}
	public double getCelcius() {
		return celcius;
	}

	public double getReamur(double c) {
		return c * 0.8;
	}
	public double getFahrentheit(double c) {
		return c * 1.8 + 32;
	}
	public double getKelvin(double c) {
		return c + 273;
	}
} 
