import java.util.Scanner;
public class inputan extends volume {
	public static void main(String[] args) {
		volume vol = new volume();
		Scanner in = new Scanner(System.in);

		System.out.println("Masukkan nilai Sisi : ");
		int p = in.nextInt();
		System.out.println();

		System.out.println(vol.hitungvol(p));
	}
}