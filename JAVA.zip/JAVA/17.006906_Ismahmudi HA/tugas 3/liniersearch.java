public class liniersearch {
	public static void main(String[] args) {
		int angka[] = new int [5];
		angka[0] = 5;
		angka[1] = 2;
		angka[2] = 7;
		angka[3] = 9;
		angka[4] = 4;
	}
}