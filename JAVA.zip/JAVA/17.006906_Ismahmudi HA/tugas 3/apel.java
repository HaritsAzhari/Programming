public class apel extends buah {
	void pesan() {
		super.pesan();
		System.out.println("Apa iyaaaa??");
	}
}