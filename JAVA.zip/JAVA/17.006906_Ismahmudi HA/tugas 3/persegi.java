public class persegi {
	private int sisi;

	public int getSisi() {
		return sisi;
	}
	public void setSisi(int a) {
		this.sisi = a;
	}
}