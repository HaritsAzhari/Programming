public class buah {
		void pesan() {
			System.out.println("Buah kesukaan anda??");
	}
	public static void main(String[] args) {
		apel a = new apel();

		a.pesan();
	}
}

5