public class transpot {
	public int roda;
	public String warna;
	public int tempat;

	public void setRoda(int roda) {
		this.roda = roda;
	}
	public void setWarna(String warna) {
		this.warna = warna;
	}
	public void setTempat(int tempat) {
		this.tempat = tempat;
	}
	public int getRoda() {
		return roda;
	}
	public String getWarna() {
		return warna;
	}
	public int getTempat() {
		return tempat;
	}
}