class mobil extends transpot {
	
}