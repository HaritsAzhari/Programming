class motor extends transpot {
	
}