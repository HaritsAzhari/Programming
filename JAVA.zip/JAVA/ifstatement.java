public class ifstatement
{
	public static void main(String []args)
	{
	int pembelian =110;
	System.out.println("Jumlah pembelian = "+ pembelian);

	if (pembelian >= 100) {
	System.out.println("Diskon = 20%");
}
	else {
	System.out.println("Diskon = 5%");
	}
    }
}