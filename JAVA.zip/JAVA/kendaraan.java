public class 

public class kendaraan {
	int roda; //masukkan variabel roda
	void jumlah(int roda) {
		this.roda = roda; //menunjukkan variable int roda
		if(roda == 2) {
			System.out.println("+=====================+");
			System.out.println("|kendaraan anda Motor |");
			System.out.println("|>>Motor Honda        |");
			System.out.println("|>>Motor Yamaha       |");
			System.out.println("|>>Motor Suzuki       |");
			System.out.println("+=====================+");		
		}
		else if (roda == 3) {
			System.out.println("+=====================+");
			System.out.println("| Kendaraan anda Bemo |");
			System.out.println("|  Bemo Kualitas limo |");
			System.out.println("+=====================+");
		} 
		else if (roda == 4) {
			System.out.println("+=====================+");
			System.out.println("|Kendaraan anda Mobil |");
			System.out.println("|>>Mobil Toyota       |");
			System.out.println("|>>Mobil Honda        |");
			System.out.println("|>>Mobil Dihatsu      |");
			System.out.println("======================+");
		}
		else if (roda > 4) {
			System.out.println("=====================");
			System.out.println("||Coba pikir lagee!||");
			System.out.println("=====================");
		}
	}
}