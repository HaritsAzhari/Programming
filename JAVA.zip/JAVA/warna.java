public class warna {
	String warna; //masukkan variabel roda
	void jumlah(int roda) {
		this.warna = warna; //menunjukkan variable int roda
		if(warna == hitam) {
			System.out.println("kendaraan anda Motor"+ warna);	
		}
		else if (warna == kuning) {
			System.out.println("kendaraan anda Bemo"+ warna);
		} 
		else if (warna == merah) {
			System.out.println("kendaraan anda Mobil"+ warna);
		}
	}
}