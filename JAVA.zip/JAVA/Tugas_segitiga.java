public class Tugas_segitiga
{
public static void main(String[] args) {
	int row;
	row=5;

	for (int i=1;i<=row ;i++) {
		for (int j=1;j<=row ;j++ ) {
			if (j<=i) 
				System.out.print("1");
			else
				System.out.print(" ");
			}
			System.out.println();
		}
	}
}