import java.util.Scanner;
public class luasprisma
{
public static void main(String []args)
	{
	Scanner masukkan = new Scanner(System.in);
	int AS,TS,TP;
	System.out.print("masukkan nilai var Alas Segitiga   : ") + cm");
		AS = masukkan.nextInt();
	System.out.print("masukkan nilai var Tinggi Segitiga : ") + cm");
		TS = masukkan.nextInt(); 
	System.out.print("masukkan nilai var Tinggi Prisma   : ") + cm");
		TP = masukkan.nextInt();
	System.out.println();
	System.out.println("variabel yang terdapat dalam program :");
	System.out.println("luas   Prisma = " + (0.5*AS*TS*TP)+ "cm");
	System.out.println("volume Prisma = " + (AS*TP)+ "cm");
	}
}