public class array2ordo {
	public static void main(String[] args) {
		int[][] data=new int[3][4]; //Menunjukkan berapa baris & berapa kolom
		for (int i=0;i<data.length;i++ ) { //Menunjukkan berapa jumlah baris data
		for (int j=0;j<data[i].length;j++ ) { //menunjukkan berapa jumlah kolom
		data [i][j]=i; //Memasukkan data ke cell (potongan baris dan kolom)
					   //Bisa diganti dengan input dari keyboard
		System.out.print(data[i][j]); //Menampilkan data monitor
		}
			System.out.println("  next data");
		}
	}
}