import java.util.Scanner;
public class Matrik3x2
{
	public static void main(String[] args) {
		int baris,kolom,x,y;
		Scanner in=new Scanner(System.in);
		System.out.println("masukkan Ordo Matriks");
		System.out.println("===========================");
		System.out.print("Masukkan jumlah baris : ");
		baris = in.nextInt();
		System.out.print("Masukkan Jumlah kolom : ");
		kolom = in.nextInt();

		int A[][] = new int[baris][kolom];
		int B[][] = new int[baris][kolom];
		int sum[][]= new int[baris][kolom];

		System.out.println("\nMasukkan Elemen matrix A");
		System.out.println("============================");
		for (x=0;x<baris ;x++ ) 
		{
		for (y=0; y<1;y++ ) 
		{	
		System.out.print("[" +(x+1)+ "][" +(y+1)+ "]:");
		A[x][y] = in.nextInt();		
			}	
		}
		System.out.println("\nMasukkan Elemen matrix B");
		System.out.println("============================");
		{
			for (x=0; x<baris; x++ ) 
			{
				for (y=0; y<kolom; y++) 
				{
					System.out.print("[" +(x+1)+ "][" +(y+1)+ "]:");
					B[x][y] = in.nextInt();
				}
				for (x=0;x<baris;x++)
				{
					for (y=0;y<kolom ;y++ ) 
					{
						sum[x][y] = A[x][y]+B[x][y];
					}
				}
				System.out.println("\nHasil penjumlahan Matrix");
				System.out.println("============================");
				for (x=0;x<baris ;x++ ) 
				{
					for (y=0;y<kolom ;y++ ) 
					{
						System.out.print(sum[x][y]+"\t");
					}
					System.out.println();
				}
			}
		}
	}
}