public class switch
{
	public static void main(String [] z)
	{
	 char nilai ='f';
	 string predikat;
	 switch(nilai)
	 {
	 	case 'a' :
			Predikat="Excellent";
			break;
		case 'b' :
			Predikat="Good";
			break;
		case 'c' :
			Predikat="OK";
			break;
		case 'd' :
			Predikat="Bad";
			break;
		case 'e' :
			Predikat="Not Identified";
			break;
	 }
	System.out.println(Predikat);
	}
}