import java.util.Arrays;
import java.util.Scanner;

public class Tugas_shorting {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);

		System.out.print ("Masukkan Jumlah Total bilangan A : ");
		int[] bilangan = new int [input.nextInt()];

		for (int i=0;i<bilangan.length ;i++ ) {
			System.out.print("Masukkan bilangan ke-"+(i+1)+" "+": ");
			bilangan[i] = input2.nextInt();
		}

		System.out.println ("bilangan Sebelum Disorting Selection Short : "+ Arrays.toString(bilangan));
		System.out.println ("\nProses Bubbleshort secara ascending: ....");
		System.out.println();

		int i=0;

			for (i = 0; i<bilangan.length-1 ; i++ ) {
				int index = i;

				System.out.println("iterasi ke-"+(i+1));

				for (int j = i+1; j< bilangan.length; j++ ) {
					if (bilangan[j]< bilangan[index]) {
						index = j;
					}
				}
				int temp = bilangan[index];
				bilangan[index] = bilangan [i];
				bilangan[i] = temp;

				System.out.println(Arrays.toString(bilangan));
				System.out.println();
			}

		Scanner input3 = new Scanner(System.in);
		Scanner input4 = new Scanner(System.in);

		System.out.print ("Masukkan Jumlah Total bilangan B : ");
		int[] bilangan2 = new int [input3.nextInt()];

		for (int a=0;a<bilangan2.length ;a++ ) {
			System.out.print("Masukkan bilangan ke-"+(a+1)+" "+": ");
			bilangan2[a] = input4.nextInt();
		}

		System.out.println ("bilangan Sebelum Disorting Selection Short : "+ Arrays.toString(bilangan2));
		System.out.println ("\nProses Bubbleshort secara ascending: ....");
		System.out.println();

		int a = 0;

			for (a = 0; a<bilangan2.length-1 ; a++ ) {
				int index2 = a;

				for (int b = a+1; b< bilangan2.length; b++ ) {
					if (bilangan2[b]< bilangan2[index2]) {
						index2 = b;
					}
				}
				int temp2 = bilangan2[index2];
				bilangan2[index2] = bilangan2[a];
				bilangan2[a] = temp2;

				System.out.println(Arrays.toString(bilangan2));
				System.out.println();
			}
		System.out.println("A. Hasil akhir setelah di sorting: "+Arrays.toString(bilangan));
		System.out.println("B. Hasil akhir setelah di sorting: "+Arrays.toString(bilangan2));
			if (bilangan[i] > bilangan2[a]) {
				System.out.println ("Nilai A menang!!!");
			}
			else if (bilangan[i] == bilangan2[a]) {
				System.out.println ("Nilai B menang!!!");
			}
			else  {
				System.out.println ("Nilai SERI !");
			}
	}
}