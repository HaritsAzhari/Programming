import java.util.Scanner;
public class prisma
{
public static void main(String []args)
	{
	Scanner masukkan = new Scanner(System.in);
	int AS,TS,TP;
	System.out.print("masukkan nilai var Alas Segitiga   : ");
		AS = masukkan.nextInt();
	System.out.print("masukkan nilai var Tinggi Segitiga : ");
		TS = masukkan.nextInt(); 
	System.out.print("masukkan nilai var Tinggi Prisma   : ");
		TP = masukkan.nextInt();
	System.out.println();
	System.out.println("variabel yang terdapat dalam program :");
	System.out.println("luas   Prisma = " + (0.5*AS*TS*TP) + " cm^2");
	System.out.println("volume Prisma = " + (AS*TP) + " cm^3");
	}
}