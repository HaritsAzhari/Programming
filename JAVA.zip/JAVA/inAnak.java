public class inAnak {
	String name;
	int hp;
	int attackpoin;
}

	void attack() {
		System.out.println("Serang !")
	}