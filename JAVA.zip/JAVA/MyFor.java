public class MyFor
{
	public static void main(String [] o)
	{
		int hitung;
		for(hitung=0;hitung<10;hitung++)
		{
			System.out.println("hallo dunia - "+hitung);
		}
	}
}