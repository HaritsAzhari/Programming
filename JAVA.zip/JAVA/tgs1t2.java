public class tgs1t2
{
	public static void main(String [] o)
	{
		int a,b,c;
		for(a=1;a<5;a++)
		for(b=12;b>=3;b-=3)
		{
		c=a*b;
		System.out.println(a+" x "+b +"=" +c);
		}
	}
}