import java.util.Arrays;
import java.util.Scanner;

public class sortHuruf {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);

		System.out.print("Masukkan jumlah total kata : ");
		String[] huruf = new String[input.nextInt()];

		for (int i=00; i<huruf.length;i++ ) {
			System.out.print("Masukkan kata ke-"+(i+1)+": ");
			huruf[i] = input2.next();
		}
		System.out.println("Kata sebelum di sorting Bubble Sort : "+ Arrays.toString(huruf));

		System.out.println("\n Proses Buble sort Secara Ascending : ...");
		for (int a=0; a<huruf.length; a++ ) {
			System.out.println("iterasi ke-"+(a+1));
			for (int b=0; b<huruf.length-1; b++) {
					if (huruf[b].compareTo(huruf[b+1]) > 0) {
						String temp = huruf[b];
						huruf [b] = huruf [b+1];
						huruf [b+1] = temp;
					}
					System.out.println(Arrays.toString(huruf));
			}
			System.out.println();
		}
		System.out.println("Hasil akhir setelah sorting: "+ Arrays.toString(huruf));
	}
}