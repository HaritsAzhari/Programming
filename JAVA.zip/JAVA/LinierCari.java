import java.util.Scanner;

public class LinierCari {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		boolean ketemu = false;
		int pos = 0;
		int cari;

		System.out.print("Masukkan jumlah total bilangan : ");
		int[]angka = new int[input.nextInt()];

		for (int i=00; i<angka.length; i++) {
			System.out.print("Masukkan angka ke-"+(i+1)+ ": ");
			angka[i] = input.nextInt();
		}
		Scanner baca = new Scanner(System.in);
		System.out.print("Masukkan Bilangan yang ingin dicari : ");
		cari = baca.nextInt();

		while((!ketemu)  &&(pos < angka.length)) {
			if (cari==angka[pos]) {
				System.out.println("Data " +cari+" Ditemukan diposisi : "+(pos+1) );
				ketemu = true;
			}
			if (!ketemu && pos != angka.length) {
				System.out.println("Data " +cari+ " Tidak ditemukan!!" );
				ketemu = true;
			}
			pos++;
		}
	}
}