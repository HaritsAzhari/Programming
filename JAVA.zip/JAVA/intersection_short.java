import java.util.Arrays;
import java.util.Scanner;

public class intersection_short {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);

		System.out.print ("Masukkan Jumlah Total bilangan : ");
		int[] bilangan = new int [input.nextInt()];

		for (int i=0;i<bilangan.length ;i++ ) {
			System.out.print("Masukkan bilangan ke-"+(i+1)+" "+": ");
			bilangan[i] = input2.nextInt();
		}

		System.out.println ("bilangan Sebelum Disorting Intersection Short : "+ Arrays.toString(bilangan));
		System.out.println ("\nProses Intersection secara ascending ....");
		System.out.println();

			for (int a = 0; a<bilangan.length ; a++ ) {
				int min = bilangan[a];
				int j = a;
				while ((j>0) && (min<bilangan[j-1])) {
					bilangan[j] = bilangan[j-1];
					j--;
				}
				bilangan[j] = min;
				System.out.println(Arrays.toString(bilangan));
				System.out.println();
			}
		System.out.println();
		System.out.println("Hasil akhir setelah di sorting: "+Arrays.toString(bilangan));
	}
}