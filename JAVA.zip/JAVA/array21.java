public class array21
{
	public static void main(String[] args)
	{
	int[]nilai={1,2,3,4,5};
	System.out.println(nilai[0]);
	}
}