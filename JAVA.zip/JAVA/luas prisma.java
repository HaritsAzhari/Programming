import java.util.Scanner;
public class luas prisma
{
public static void main(String []args)
	{
	Scanner masukkan = new Scanner(System.in);
	int panjang,lebar,tinggi;
	System.out.print("masukkan nilai var panjang : ");
		panjang = masukkan.nextInt();
	System.out.print("masukkan nilai var lebar : ");
		lebar = masukkan.nextInt();
	System.out.println();
	System.out.println("variabel yang terdapat dalam program :");
	System.out.println("panjang = " + panjang);
	System.out.println("var_b = " + lebar);
	}
}