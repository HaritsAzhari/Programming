public class testing 
{	
	public static void main (String [] x) 
	{
	System.out.println("what's wrong with this program?");
}
}