import java.util.Scanner;
public class mySwitch
{
	public static void main(String[] args)
	{
	 Scanner mlebu = new Scanner(System.in);
	 char nilai;
	 String predikat;
	
		System.out.println();
	 	System.out.print("Masukkan predikat : ");
		nilai = mlebu.next().charAt(0);
		switch(nilai)
	 {
	 	case 'a' :
			predikat="Excellent";
			break;
		case 'b' :
			predikat="Good";
			break;
		case 'c' :
			predikat="OK";
			break;
		case 'd' :
			predikat="Bad";
			break;
		case 'e' :
			predikat="Not Identified";
			break;
		default:
			predikat="salah input";
			break;
	 }
	System.out.println(predikat);
}
}