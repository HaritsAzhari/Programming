import java.util.Scanner;
public class matrik3
{
    public static void main(String[] args)
    {
        Scanner inputan= new Scanner (System.in);
        int A[][]=new int[3][3];
        int B[][]=new int[3][3];
        int C[][]=new int[3][3];
        int D[][]=new int[3][3];
        int E[][]=new int[3][3];
         
        System.out.println("Masukkan Nilai Matriks A");
        System.out.println("=======================");
        for(int a=0;a<3;a++)
        {
            for(int b=0;b<3;b++)
            {
                System.out.print("[" +(a+1)+ "][" +(b+1)+ "]:");
                A[a][b]=inputan.nextInt();
            }
        }
      
        System.out.println("\nMasukkan Nilai Matriks B");
        System.out.println("==========================");
        for(int a=0;a<3;a++)
        {
            for(int b=0;b<3;b++)
            {
                System.out.print("[" +(a+1)+ "][" +(b+1)+ "]:");
                B[a][b]=inputan.nextInt();
            }
        }
      
            // Melakukan penjumlahan,pengurangan, dan perkalian matriks
        for(int a=0;a<3;a++)
        {
            for(int b=0;b<3;b++)
            {
                C[a][b]=A[a][b]+B[a][b];
                D[a][b]=A[a][b]-B[a][b];
            }
        }

      
        System.out.println("\nHasil penjumlahan Matriks");
        System.out.println("===========================");
        for(int a=0;a<3;a++)
        {
            for(int b=0;b<3;b++)
            {
                System.out.print(+(C[a][b])+" ");
            }
            System.out.println(" ");
        }
        System.out.println("\nHasil pengurangan Matriks");
        System.out.println("=============================");
         for(int a=0;a<3;a++)
        {
            for(int b=0;b<3;b++)
            {
                System.out.print(+(D[a][b])+" ");
            }
            System.out.println(" ");
        } 
        System.out.println("\nHasil Perkalian Matriks");
        System.out.println("============================");
         for(int a=0;a<3;a++)
        {
            for(int b=0;b<3;b++)
            {
                for (int c=0;c<3 ;c++ ) 
                {
                    E[a][b]+=A[a][c]*B[c][b];
                }
                System.out.print(+(E[a][b])+" ");
            }
            System.out.println(" ");
        }
    } 
}