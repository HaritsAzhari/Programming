import java.util.Scanner;
public class CVRPL
{
	public static void main(String[] args)
	{
	Scanner gaji1 = new Scanner(System.in);
	char gol, nikah, anak, junak;
	double a1, a2, gaber;
	String golo;
	int gapok;
	String nama;
	gapok = 0;
	a1 = 0;
	a2 = 0;
		System.out.println("Welcome to CV.RPL");
		System.out.print("Masukkan nama karyawan : ");
			nama = gaji1.next();
		System.out.print("Gaji pokok karyawan : ");
			gapok = gaji1.nextInt();
		System.out.print("Golongan karyawan [a s/d c] : ");
		gol = gaji1.next().charAt(0);
		switch(gol)
		{
			case 'a' :
			 gapok = 1000000; ;
			 break;
			case 'b' :
			 gapok = 750000 ;
			 break;
			case 'c' :
			 gapok = 500000 ;
			 break;
			default:
			 golo="not identified";
			 return;
		}
		System.out.print("Apakah anda Sudah menikah [y/n]: ");
		nikah = gaji1.next().charAt(0);
		if (nikah=='y')
			{
				a1=gapok*0.1;
				System.out.print("Sudah memiliki anak [y/n]: ");
				anak = gaji1.next().charAt(0);
				if (anak== 'y')
				{
					System.out.print("Jumlah anak : ");
					junak=gaji1.next().charAt(0);
					
				if (junak < 3) {
			 	   a2 = gapok*0.05*junak;
				   }
				else if (junak > 2) {
				   a2 = gapok*0.05*2;
					}
				}
		gaber = gapok+a1+a2;
		System.out.println("Gaji pokok		= Rp. "+gapok);
		System.out.println("Tunjangan nikah	= Rp. "+a1);
		System.out.println("Tunjangan anak	= Rp. "+a2);
		System.out.println("Gaji Bersih		= Rp. "+gaber);
	}
}
}