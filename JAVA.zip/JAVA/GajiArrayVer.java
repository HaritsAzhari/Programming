import java.util.Scanner; 
public class GajiArrayVer 
{ 
	public static void main (String [] args) { 
		Scanner masuk = new Scanner(System.in); 
		int x;
		String NamaKar[]; 
		char Gol[] ; 
		long GaPok[]; 
		long Ti[];
		long Ta [];
		long Gb[];                            
		char Stt[]; 
		int Anak[]; 
		int JKar;
		System.out.print("Masukan Jumlah Karyawan : ");
		JKar = masuk.nextInt();
		System.out.println("");
		NamaKar = new String[JKar];
		Gol = new char[JKar];
		GaPok = new long[JKar];
		Ti = new long[JKar];
		Ta = new long[JKar];
		Gb = new long[JKar];
		Stt = new char[JKar];
		Anak = new int[JKar]; 
		Gb = new long[JKar]; 
		for(x=0;x < JKar;x++) 
			{ System.out.print("Nama Karyawan 	    : ");
			NamaKar[x] = masuk.next();
			System.out.print("Golongan Karyawan A s/d C : "); 
			Gol[x] = masuk.next().charAt(0);
			switch(Gol[x]) { 
				case 'A' :
				GaPok[x] = 1000000; break;
				case 'B' :
				GaPok[x] = 750000;
				break;
				case 'C' :
				GaPok[x] = 500000;
				break;
				default :
				System.out.println("Data yang ada masukkan salah"); return;
					}
			System.out.print("Karyawan sudah menikah [y/t] : ");
			Stt[x] = masuk.next().charAt(0); 
			if (Stt[x] == 'y') {
						Ti[x] = GaPok[x]*10/100;
						System.out.print("Anak Karyawan : "); 
						Anak[x] = masuk.nextInt(); 
						if (Anak[x] >= 5) {
							Ta[x] = GaPok[x]*5/100 *4;
								}
						else if (Anak[x] < 5) {
						Ta[x] = GaPok[x]*5/100*Anak[x];
								}
						else {
						Ta[x] = 0;
						}
						} 
					else {
					Ti[x] = 0;
					Ta[x] = 0;		
					}
	System.out.println("");
		} for(int y=0;y<JKar;y++) {
	System.out.println("=========================================");
	System.out.println("               Gaji Karyawan             ");
	System.out.println("========================================="); 
	System.out.println("Nama Karyawan   : "+NamaKar[y]);
	System.out.println("Gaji Pokok      : "+GaPok[y]);
	System.out.println("Tunjangan Istri : "+Ti[y]);
	System.out.println("Tunjangan Anak  : "+Ta[y]);
	Gb[y] = GaPok[y] + Ti[y] + Ta[y];
	System.out.println("Gb     : "+Gb[y]); System.out.println("");
	}
}
}
