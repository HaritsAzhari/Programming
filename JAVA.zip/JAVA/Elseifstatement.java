import java.util.Scanner;
public class Elseifstatement
{
	public static void main(String []args)
	{
	Scanner masukkan = new Scanner(System.in);
	int nilai;
		System.out.print("Masukkan Nilai : ");
		nilai = masukkan.nextInt();
		System.out.println();
	System.out.println ("Nilai  : " +nilai);
	if (nilai >= 80)
		System.out.println("predikat A");
	else if (nilai >= 69)
		System.out.println("predikat B");
	else if (nilai >= 56)
		System.out.println("Predikat C");
	else if (nilai >= 40)
		System.out.println("predikat D");
	else
		System.out.println("Predikat E");
	}
}