import java.util.Arrays;
import java.util.Scanner;

public class bubbleshort { //class
	public static void main(String[] args) { //method procedure.
		Scanner input = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);

		System.out.print("masukan Jumlah Total Bilangan : ");
		int[] bilangan = new int[input.nextInt()];

		for (int i=0; i < bilangan.length; i++) {
			System.out.print("Masukkan Bilangan ke-"+(i+1)+ ": ");
			bilangan[i] = input2.nextInt();
		}

		System.out.println ("bilangan Sebelum Disorting Bubbleshort : "+ Arrays.toString(bilangan));

		System.out.println ("\nProses Bubbleshort secara ascending: ....");
		for (int a=0; a<bilangan.length; a++) {
			System.out.println("iterasi ke-"+(a+1));
				for (int b=0; b<bilangan.length-1; b++) {
					if (bilangan[b] > bilangan[b+1]) {
					
				int temp = bilangan[b];
				bilangan[b] = bilangan [b+1];
				bilangan[b+1] = temp; //
			}
			System.out.println(Arrays.toString(bilangan));
		}
		System.out.println();
	}
	System.out.println("Hasil Akhir Setelah di shorting : "+Arrays.toString(bilangan));
}
}