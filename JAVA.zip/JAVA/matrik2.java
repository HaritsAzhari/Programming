import java.util.Scanner;
public class matrik2
{
    public static void main(String[] args)
    {
        Scanner inputan= new Scanner (System.in);
        int A[][]=new int[2][2];
        int B[][]=new int[2][2];
        int C[][]=new int[2][2];
        int D[][]=new int[2][2];
        int E[][]=new int[2][2];
         
        System.out.println("Masukkan Nilai Matriks A");
        System.out.println("=======================");
        for(int a=0;a<2;a++)
        {
            for(int b=0;b<2;b++)
            {
                System.out.print("[" +(a+1)+ "][" +(b+1)+ "]:");
                A[a][b]=inputan.nextInt();
            }
        }
      
        System.out.println("\nMasukkan Nilai Matriks B");
        System.out.println("==========================");
        for(int a=0;a<2;a++)
        {
            for(int b=0;b<2;b++)
            {
                System.out.print("[" +(a+1)+ "][" +(b+1)+ "]:");
                B[a][b]=inputan.nextInt();
            }
        }
      
            // Melakukan penjumlahan,pengurangan, dan perkalian matriks
        for(int a=0;a<2;a++)
        {
            for(int b=0;b<2;b++)
            {
                C[a][b]=A[a][b]+B[a][b];
                D[a][b]=A[a][b]-B[a][b];
            }
        }

      
        System.out.println("\nHasil penjumlahan Matriks");
        System.out.println("===========================");
        for(int a=0;a<2;a++)
        {
            for(int b=0;b<2;b++)
            {
                System.out.print(+(C[a][b])+" ");
            }
            System.out.println(" ");
        }
        System.out.println("\nHasil pengurangan Matriks");
        System.out.println("=============================");
         for(int a=0;a<2;a++)
        {
            for(int b=0;b<2;b++)
            {
                System.out.print(+(D[a][b])+" ");
            }
            System.out.println(" ");
        } 
        System.out.println("\nHasil perkalian Matriks");
        System.out.println("============================");
         for(int a=0;a<2;a++)
        {
            for(int b=0;b<2;b++)
            {
                for (int c=0;c<2 ;c++ ) 
                {
                    E[a][b]+=A[a][c]*B[c][b];
                }
                System.out.print(+(E[a][b])+" ");
            }
            System.out.println(" ");
        }
    } 
}