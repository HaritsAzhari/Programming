public class lat20180801
{
	public static void main(String [] args)
	{
		System.out.println("What's wrong with this program?");
		System.out.println("This program not wrong");
		System.out.println("Really??");
		System.out.println("Yes, Iam Really");
		System.out.println("Okay, you're welcome");
		System.out.println("End.");
		System.out.println("Farid Nasrul hidayat");
		System.out.println("Yang terbaik");
		System.out.println("hahahahhahaha");
		System.out.println("unusual longer");
	}
}