public class mySwitch
{
	public static void main(String[] args)
	{
	 char nilai ='f';
	 String predikat;
	 switch(nilai)
	 {
	 	case 'a' :
			predikat="Excellent";
			break;
		case 'b' :
			predikat="Good";
			break;
		case 'c' :
			predikat="OK";
			break;
		case 'd' :
			predikat="Bad";
			break;
		case 'e' :
			predikat="Not Identified";
			break;
	 }
	System.out.println(predikat);
	}
}