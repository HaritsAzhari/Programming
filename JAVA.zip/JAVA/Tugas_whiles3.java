public class Tugas_whiles3
{
public static void main(String[] args) {
	int a,b;
	a=0;

	while (a<=5) {
		b=0; 
			while(b<a) { 
				System.out.print("1");
				b++;
				}
			System.out.println(" ");
			a++;
		}
	}
}