class kucing extends hewan {
	kucing(String jenis, int kaki) {
		super(jenis,kaki);
	}
	void bersuara() {
		super.bersuara();
		System.out.println("Miaoowww....");
	}
}