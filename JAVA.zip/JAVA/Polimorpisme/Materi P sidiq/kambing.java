class kambing extends hewan {
	kambing(String jenis, int kaki) {
		super(jenis,kaki);
	}
	void bersuara() {
		super.bersuara();
		System.out.println("Mbeek.. mbeekk...");
	}
}