public class binatang {
	void makan(){
		//System.out.println("Makan...");
	}
	void tidur(){
		//System.out.println("Tidur...");
	}
}