public class Gajah extends binatang {

	void makan() {
		System.out.println("Gajah makan ...");
	}

	void tidur() {
		System.out.println("Gajah tidur");
	}
}