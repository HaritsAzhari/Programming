public class Kerbau extends binatang {

	void makan() {
		System.out.println("Kerbau makan ...");
	}

	void tidur() {
		System.out.println("Kerbau tidur");
	}
}