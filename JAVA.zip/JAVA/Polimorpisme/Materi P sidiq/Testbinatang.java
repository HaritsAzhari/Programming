public class Testbinatang {
	static void test(binatang x) {
		x.makan();
		x.tidur();
	}	
	public static void main(String[] args) {
		Gajah bledug = new Gajah();
		Kerbau kebo = new Kerbau();


		test(bledug);
		test(kebo);
	}
}