class testpoli {
	public static void main(String[] args) {
		kambing mbek = new kambing("kambing", 4);
		kucing tom = new kucing("kucing", 4);
		mbek.bersuara();
		tom.bersuara();
	}
}