public class hewan {
	private String jenis;
	private int kaki;
	hewan() {

	}
	hewan(String jenis, int kaki){
		this.jenis = jenis;
		this.kaki = kaki;
	}
	void bersuara() {
		System.out.println("Suara hewan " +jenis+ " Berkaki " +kaki);
	}
}