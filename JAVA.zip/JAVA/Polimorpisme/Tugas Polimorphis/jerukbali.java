 class jerukbali extends buah {
	jerukbali(String nama, int jumlah) {
		super(nama,jumlah);
	}
	void jumlahnya() {
		super.jumlahnya();
		System.out.println("Pahittt...");
	}
}