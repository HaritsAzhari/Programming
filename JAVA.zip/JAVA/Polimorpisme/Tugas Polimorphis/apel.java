class apel extends buah {
	apel(String nama, int jumlah) {
		super(nama,jumlah);
	}
	void jumlahnya() {
		super.jumlahnya();
		System.out.println("Manisss...");
	}
}