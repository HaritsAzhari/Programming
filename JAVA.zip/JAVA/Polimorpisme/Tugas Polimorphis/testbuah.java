class testbuah {
	public static void main(String[] args) {
		apel malang = new apel("apel", 14);
		jerukbali bali = new jerukbali("jerukbali", 12);
		malang.jumlahnya();
		bali.jumlahnya();
	}
}