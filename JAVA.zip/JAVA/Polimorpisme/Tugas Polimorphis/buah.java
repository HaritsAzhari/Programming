public class buah {
	private String nama;
	private int jumlah;
	buah() {

	}
	buah(String nama, int jumlah){
		this.nama = nama;
		this.jumlah = jumlah;
	}
	void jumlahnya() {
		System.out.println("Nama buah " +nama+ " jumlahnya ada " +jumlah);
	}
}