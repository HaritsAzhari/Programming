public class array2
{
	public static void main(String[] args)
	{
	int [] nilai=new int[5];
		nilai[0]=1;
		nilai[1]=2;
		nilai[2]=3;
		nilai[3]=4;
		nilai[4]=5;
	System.out.println(nilai[4]);
	}
}