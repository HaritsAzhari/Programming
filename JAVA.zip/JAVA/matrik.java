import java.util.Scanner;
public class matrik
{
	public static void main(String[] args) 
	{
	Scanner inputan= new Scanner (System.in);
	int a[][]=new int[2][2];
	int b[][]=new int[2][2];
	int c[][]=new int[2][2];
	System.out.println("masukkan nilai matrix A");
	System.out.println("=======================");
	for (int i=0;1<2 ;i++ ) 
	{
		for (int j=0;j<2 ;j++ ) 
		{
			System.out.print("[" +(i+1)+ "][" +(j+1)+"]:");
			a[i][j]=inputan.nextInt();
		}
	
	
		System.out.println("masukkan nilai matriks B");
		System.out.println("===========================");
		for (int i=0;i<2 ;i++ ) 
		{
			for(int j=0;j<2;j++)
			{
				System.out.print("[" +(i+1)+ "][" +(j+1)+"]:");
			b[i][j]=inputan.nextInt();
		
	
			for (int i=0;i<2 ;i++ ) 
			{
				for (int j=0;j<2 ;j++ ) 
				{
					c[i][j]=a[i][j]+b[i][j];
				}	
			}
			System.out.println("masukkan penjumlahan matriks");
			System.out.println("===============================");
			for (int i=0;i<2 ;i++ ) 
			{
				for (int j=0;j<2 ;j++ ) 
				{
				System.out.print(+(c[i][j])+" ");
			}
			System.out.println(" ");
		}
	}
}