import java.util.Arrays;
import java.util.Scanner;

public class Selection_short {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Scanner input2 = new Scanner(System.in);
		System.out.print ("Masukkan Jumlah Total bilangan : ");
		int[] bilangan = new int [input.nextInt()];
		for (int i=0;i<bilangan.length ;i++ ) {
			System.out.print("Masukkan bilangan ke-"+(i+1)+" "+": ");
			bilangan[i] = input2.nextInt();
		}
		System.out.println ("bilangan Sebelum Disorting Selection Short : "+ Arrays.toString(bilangan));
		System.out.println ("\nProses Bubbleshort secara ascending: ....");
		System.out.println();
		int i=0;
			for (i = 0; i<bilangan.length-1 ; i++ ) {
				int index = i;
				System.out.println("iterasi ke-"+(i+1));
				for (int j = i+1; j< bilangan.length; j++ ) {
					if (bilangan[j]< bilangan[index]) {
						index = j;
					}
				}
				int temp = bilangan[index];
				bilangan[index] = bilangan [i];
				bilangan[i] = temp;

				System.out.println(Arrays.toString(bilangan));
				System.out.println();
			}
		System.out.println("Hasil akhir setelah di sorting: "+Arrays.toString(bilangan));
	}
}